"""
Run once to seed the database with demo products and an admin user.
Usage:  python seed.py
"""
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from app.database import SessionLocal, engine, Base
from app.models.user import User
from app.models.product import Product
from app.routes.auth import hash_password

# import all models so Base.metadata knows about them
import app.models.cart   # noqa
import app.models.order  # noqa

Base.metadata.create_all(bind=engine)

db = SessionLocal()

# ── admin user ─────────────────────────────────────────────────────────────────
if not db.query(User).filter(User.username == "admin").first():
    db.add(User(username="admin", hashed_password=hash_password("admin123"), is_admin=True))
    print("Created admin user  (password: admin123)")

# ── demo user ──────────────────────────────────────────────────────────────────
if not db.query(User).filter(User.username == "demo").first():
    db.add(User(username="demo", hashed_password=hash_password("demo123")))
    print("Created demo user   (password: demo123)")

# ── products ───────────────────────────────────────────────────────────────────
if db.query(Product).count() == 0:
    products = [
        Product(name="Mechanical Keyboard", description="Tactile clicky 87-key TKL layout", price=89.99, stock=25),
        Product(name="Wireless Mouse",       description="Ergonomic 3200 DPI silent clicks", price=39.99, stock=40),
        Product(name="4K Monitor",           description='27" IPS panel, 144Hz, HDR400',    price=349.99, stock=10),
        Product(name="USB-C Hub",            description="7-in-1 multiport adapter hub",     price=24.99, stock=60),
        Product(name="Webcam 1080p",         description="Auto-focus with noise-cancel mic", price=59.99, stock=30),
        Product(name="Desk Lamp LED",        description="Touch dimmer, 3 colour temps",     price=19.99, stock=50),
    ]
    db.add_all(products)
    print(f"Seeded {len(products)} products")

db.commit()
db.close()
print("Seed complete.")
